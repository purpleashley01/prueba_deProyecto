package balance;
import java.util.Scanner;
public  class CalculosMetodos extends balance_general{
	Scanner tc=new Scanner(System.in);

	@Override
	public void Calcular() {
		System.out.println("-----------Activos Circulantes---------");
		System.out.println("ingrese caja");
		caja=tc.nextDouble();
		System.out.println("ingrese bancos");
		bancos=tc.nextDouble();
		System.out.println("ingrese documentos por cobrar");
		documentosxcobrar=tc.nextDouble();
		System.out.println("ingrese deudores diversos");
		deudoresdiversos=tc.nextDouble();
		System.out.println("ingrese almacen");
		almacen=tc.nextDouble();
		
	    totalactivocirculante=caja+bancos+documentosxcobrar+deudoresdiversos+almacen;
	
	    System.out.println("-----------Activo FIJO-----------");
	    System.out.println("Ingrese Equipo de Oficina");
	    equipodeoficina=tc.nextDouble();
	    System.out.println("Ingrese Edificio");
	    edificio=tc.nextDouble();
	    System.out.println("Ingrese Terrenos");
        terrenos=tc.nextDouble();
	
    totalactivofijo=equipodeoficina+edificio+terrenos;
    
        System.out.println("----------Cargos Diferidos----------");
	    System.out.println("Ingrese Primas");
	    primas=tc.nextDouble();
	    System.out.println("Ingrese Gastos de instalacion ");
        gastosdeinstalcion=tc.nextDouble();
        System.out.println("Ingrese Rentas anticipadas");
        rentasanticipadas=tc.nextDouble();

    totalcargosdiferido=primas+gastosdeinstalcion+rentasanticipadas;

        TotalActivos=totalactivocirculante+totalactivofijo+totalcargosdiferido;
    
        System.out.println("-----------Pasivo Circulante-----------");
        System.out.println("Ingrese Proveedores");
        proveedores=tc.nextDouble();
        System.out.println("Ingrese Cuentas por Pagar");
        cuentasxpagar=tc.nextDouble();
        System.out.println("Ingrese Acreedores");
         acreedores=tc.nextDouble();
         TotalPasivoCirculante= proveedores+cuentasxpagar+acreedores;
	
         System.out.println("-----------Pasivo Fijo----------");
         System.out.println("Ingrese Documentos por Pagar a largo plazo");
        documentosxpagarlargoplazo=tc.nextDouble();
        System.out.println("Ingrese Hipotecas");
         hipotecas=tc.nextDouble();		
        TotalPasivoFijo= documentosxpagarlargoplazo+hipotecas;

          System.out.println("---------Creditos Diferidos--------");
        System.out.println("Ingrese Rentas Cobradas por Adelantado");
        rentascobradasxadelantado=tc.nextDouble();
        System.out.println("Ingrese Intereses Cobrados Anticipadamente");
         interesescobradosanti=tc.nextDouble();		
        TotalCreditoDiferido=rentascobradasxadelantado+ interesescobradosanti;

         System.out.println("-----------Capital-----------");
         System.out.println("Ingrese Capital");
         capital=tc.nextDouble();
         System.out.println("Ingrese Capital Social");
          capitalsocial=tc.nextDouble();	

         TotalCapital=capital+capitalsocial;
         TotalPasivoCapital=TotalPasivoCirculante+TotalPasivoFijo+TotalCreditoDiferido+TotalCapital;

           System.out.println("------------------Estado Financiero------------------");
           System.out.println("\n------ACTIVO------");
           System.out.println("\n-----Activos Circulantes-----");
           System.out.println("Caja______________________"+caja);
           System.out.println("Banco_____________________"+bancos);
           System.out.println("Clientes__________________"+clientes);
           System.out.println("Documentos por cobrar_____"+documentosxcobrar);
           System.out.println("Deudores diversos_________"+deudoresdiversos);
           System.out.println("Almacen___________________"+almacen);
           System.out.println("Total Activo Circulante___"+totalactivocirculante);

           System.out.println("\n--------Activos Fijo---------");	
           System.out.println("Equipo de Oficina_________"+equipodeoficina);
           System.out.println("Edificio__________________"+edificio);
           System.out.println("Terrenos__________________"+terrenos);

           System.out.println("Total Activo Fijo_________"+totalactivofijo);
           
           System.out.println("\n-------Cargos Diferidos-------");
		   System.out.println("primas____________________"+primas);
		   System.out.println("gastos de instalacion_____"+gastosdeinstalcion);
		   System.out.println("rentas anticipadas________"+rentasanticipadas);
		   System.out.println("\nTotal Cargos Diferidos__"+totalcargosdiferido);
		   System.out.println("TOTAL ACTIVOS_____________"+TotalActivos);

		   System.out.println("\nPASIVO");
		   System.out.println("\n------Pasivo Circulante------");	
		   System.out.println("Proveedores_______________"+proveedores);
		   System.out.println("Cuentas por pagar_________"+cuentasxpagar);
		   System.out.println("Acreedores________________"+acreedores);
		   System.out.println("Total Pasivo Circulante___"+TotalPasivoCirculante);
			
		   System.out.println("\n---------Pasivo Fijos---------");	
		   System.out.println("Documentos por Pagar a largo plazo____"+documentosxpagarlargoplazo);
		   System.out.println("Hipotecas_________________"+hipotecas);
			
		   System.out.println("Total Pasivo Circulante___"+TotalPasivoFijo);
			
		   System.out.println("\n-------Creditos Diferidos------");
    	   System.out.println("Rentas Cobradas por Adelantado________"+rentascobradasxadelantado);
		   System.out.println("Intereses Cobrados Anticipadamente____"+interesescobradosanti);
		   System.out.println("Total Creditos Diferidos______________"+TotalCreditoDiferido);
			
		   System.out.println("\n------------Capital------------");
	       System.out.println("Capital____________________" +capital);
		   System.out.println("Capital Social_____________"+ capitalsocial);
		   System.out.println("\nTotal Capital____________"+TotalCapital);
		   System.out.println("TOTAL PASIVO+CAPITAL_______"+TotalPasivoCapital);
			
			
	}

}
