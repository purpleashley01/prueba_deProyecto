package balance;
import java.util.*;

public class BalanceGeneralApp  {

	public static void main(String[] args) {
		Scanner c= new Scanner(System.in);
		
		String use = "admin";
		int pass=123, cont = 1;	
		
		while(use!="admin" || pass!=123 || cont<=3) {
			System.out.println("Ingrese su Usuario");
			use=c.nextLine();
			System.out.println("Ingrese su Password");
			pass=c.nextInt();
			c.nextLine();
			if(use.equals(use)&& pass==123) {
				System.out.println("Bienvenido a Ingresado al Sistema");
				CalculosMetodos cm = new CalculosMetodos();
				cm.Calcular();
				
				
				
				
				break;
			}
		}
	}


}
