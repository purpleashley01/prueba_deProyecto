package balance;

public abstract  class balance_general {

protected double caja,bancos,clientes,documentosxcobrar,deudoresdiversos,almacen;
protected double equipodeoficina,edificio,terrenos;
protected double primas,gastosdeinstalcion,rentasanticipadas;
protected double proveedores,cuentasxpagar,acreedores;
protected double documentosxpagarlargoplazo,hipotecas;
protected double rentascobradasxadelantado,interesescobradosanti;
protected double capital,capitalsocial;
protected double totalactivocirculante,totalactivofijo,TotalCapital,totalcargosdiferido,TotalCreditoDiferido,TotalPasivoCirculante,TotalPasivoFijo;
protected double TotalActivos,TotalPasivoCapital;


public abstract void Calcular();
//public abstract void Resultado();
}
